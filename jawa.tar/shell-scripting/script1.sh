myvar='shell scripting'
echo $myvar

jlas
jlsa;l


